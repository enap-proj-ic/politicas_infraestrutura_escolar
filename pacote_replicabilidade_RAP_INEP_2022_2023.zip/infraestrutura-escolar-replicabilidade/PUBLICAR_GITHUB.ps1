# Executar em PowerShell a partir da pasta extraída do pacote.
# Requer: Git e GitHub CLI (gh), autenticado na conta do pesquisador.
# Atenção: cria repositório PÚBLICO; não inclui o manuscrito nem histórico do estudo original.
$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot
if (-not (Get-Command git -ErrorAction SilentlyContinue)) { throw 'Git não instalado.' }
if (-not (Get-Command gh -ErrorAction SilentlyContinue)) { throw 'GitHub CLI (gh) não instalado.' }
& gh auth status
if ($LASTEXITCODE -ne 0) { throw 'GitHub CLI não autenticado. Execute gh auth login.' }
$owner = (& gh api user --jq '.login').Trim()
if ($LASTEXITCODE -ne 0 -or $owner -cne 'cairesmachado-svg') { throw ('GitHub autenticado como ' + $owner + '. Selecione a conta pessoal correta.') }
$repo = 'cairesmachado-svg/infraestrutura-escolar-replicabilidade'
if (Test-Path '.git') { throw 'Esta pasta já contém .git. Verifique antes de continuar.' }
& git init -b main
if ($LASTEXITCODE -ne 0) { throw 'Falha no git init.' }
& git add README.md FONTES_INEP.md NOTAS_ETICA_E_PUBLICACAO.md MANIFESTO_SHA256.json PUBLICAR_GITHUB.ps1 .gitignore requirements.txt data/ scripts/ resultados/ protocolo/
& git diff --cached --check
if ($LASTEXITCODE -ne 0) { throw 'Falha no git diff --check.' }
& git diff --cached --stat
Write-Host 'ATENÇÃO: o próximo comando criará um repositório PÚBLICO na conta pessoal indicada.'
$confirmacao = Read-Host 'Digite PUBLICAR para prosseguir'
if ($confirmacao -cne 'PUBLICAR') { throw 'Publicação cancelada.' }
& git commit -m 'data: disponibiliza pacote congelado de replicabilidade INEP 2022-2023'
if ($LASTEXITCODE -ne 0) { throw 'Falha no commit. Configure user.name e user.email no seu Git.' }
& gh repo create $repo --public --source . --remote origin --push --description 'Pacote de replicação de modelos sobre infraestrutura escolar e IDEB, com dados oficiais do INEP'
if ($LASTEXITCODE -ne 0) { throw 'Falha na criação ou no push: verifique antes de repetir.' }
& git remote -v
& git log -1 --oneline
Write-Host ('Repositório criado: https://github.com/' + $repo)
