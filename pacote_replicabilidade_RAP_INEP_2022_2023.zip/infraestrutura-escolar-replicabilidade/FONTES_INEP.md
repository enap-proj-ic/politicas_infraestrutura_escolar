# Fontes oficiais dos dados

Todos os insumos empíricos referem-se a dados institucionais no nível de escola divulgados pelo Instituto Nacional de Estudos e Pesquisas Educacionais Anísio Teixeira (INEP). As séries têm anos diferentes; estes são os anos efetivamente usados nos modelos, independentemente das atualizações mais recentes dos portais.

- Censo Escolar da Educação Básica **2022**, incluindo cadastro das escolas e dicionário dos campos: https://www.gov.br/inep/pt-br/acesso-a-informacao/dados-abertos/microdados/censo-escolar
- Indicador de Nível Socioeconômico (INSE) **2021**, por escola: https://www.gov.br/inep/pt-br/acesso-a-informacao/dados-abertos/indicadores-educacionais/nivel-socioeconomico/2021
- Indicador de Regularidade do Docente (IRD) **2022** e Indicador de Complexidade de Gestão (ICG) **2022**: https://www.gov.br/inep/pt-br/acesso-a-informacao/dados-abertos/indicadores-educacionais
- IDEB **2023**, anos finais, por escola: https://www.gov.br/inep/pt-br/areas-de-atuacao/pesquisas-estatisticas-e-indicadores/ideb/resultados
- Taxa de abandono **2022**, anos finais, utilizada somente na sensibilidade S2: https://www.gov.br/inep/pt-br/acesso-a-informacao/dados-abertos/indicadores-educacionais

As referências originais e os arquivos específicos da extração encontram-se nos manifestos internos do estudo; para reexecutar o processo do arquivo oficial bruto até a base final, será preciso consolidar em um script público o procedimento de cruzamento e filtragem. **Este pacote oferece a base analítica congelada e reprodução direta dos modelos, não o fluxo bruto-completo.**

Não substituir INSE 2021, IRD 2022, Censo 2022 ou IDEB 2023 por edições posteriores sem documentar uma versão metodológica distinta.
