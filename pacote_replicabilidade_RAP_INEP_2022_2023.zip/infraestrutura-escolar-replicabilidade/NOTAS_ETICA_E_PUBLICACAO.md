# Verificação de publicação — RAP/FGV, 18/11/2026

Fonte oficial: https://periodicos.fgv.br/rap/enviodeartigos e https://periodicos.fgv.br/rap/normaseticas

A RAP **recomenda** o depósito de dados e materiais em repositório de dados, dá como exemplos Zenodo, Mendeley Data e Harvard Dataverse e prevê declaração de disponibilidade de dados. GitHub é útil para software e histórico de mudanças, mas **não substitui automaticamente** o depósito arquivístico com DOI. A publicação deste pacote no GitHub não é submissão do artigo.

A versão V2 relatada pelos autores tem 7.893 palavras no DOCX, 12 palavras no título em português, resumos de 212/199/232 palavras. Pelas informações relatadas, está dentro dos intervalos da RAP para Artigo Original: 6.000–8.000 palavras totais, títulos com até 12 palavras por idioma e resumos de 150–250 palavras. **Essas contagens não foram reexecutadas nesta entrega sobre a V2, que está no workspace dos autores.** O texto completo, figura, formatação, PDF e anonimização dependem do preflight final no diretório original.

A RAP usa revisão duplo-cega. Um repositório público hospedado em uma conta pessoal pode identificar indiretamente os autores se o manuscrito cego fornecer diretamente o link. Os autores devem consultar as diretrizes de anonimização e decidir a forma de encaminhar dados aos pareceristas sem comprometer o processo.

A política de IA permite apoio limitado à edição e exige transparência. O histórico documentado deste projeto inclui uso de IA na organização, programação e redação provisória de trechos. **Não utilizar declaração de ausência de IA**. Necessária revisão intelectual pelos coautores e esclarecimento editorial se permanecer dúvida de conformidade.

Pendente: declaração de dados para o manuscrito, aprovação de autores, DOI do depósito, CRediT, ORCID, conflitos de interesse, financiamento, verificação da licença de software e dos dados de terceiros. O repositório não inclui o manuscrito de submissão, correspondências, notas autorais ou histórico privado.
