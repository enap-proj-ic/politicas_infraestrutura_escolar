# Infraestrutura escolar e implementação de políticas públicas: materiais de replicação

**Estado:** pacote técnico independente, preparado em 18/11/2026. **Não representa artigo submetido, aceito ou publicado.** O manuscrito e os documentos de deliberação dos coautores não integram este pacote.

## Escopo

Material que permite **reproduzir numericamente, a partir da base analítica final**, os modelos de mínimos quadrados ordinários M0–M2, as sensibilidades S1/S2, a sensibilidade de forma funcional S3 e as respectivas inferências CR1 municipal e HC3. O conjunto analítico contém **27.315 escolas públicas** de **5.228 municípios**, com Censo Escolar 2022, INSE 2021, IRD/ICG 2022 e IDEB anos finais 2023. Os indicadores físicos são binários de dependências **existentes e utilizadas**; não medem conservação, manutenção nem qualidade do Facilities Management.

**Limite importante:** o pacote não recompõe autonomamente a base analítica a partir dos downloads oficiais brutos; a fase de cruzamento R1 utiliza arquivos e etapas do histórico do estudo que ainda precisam de uma rotina ETL pública única e validada. A base analítica e os resultados congelados foram preservados com hashes. Não anunciar "reprodutibilidade ponta a ponta a partir do bruto" antes de preparar e testar essa etapa.

## Conteúdo

- `data/base_analitica_final.csv`: amostra final, 17 colunas, registros no nível de escola. O código da escola é uma chave cadastral oficial, não um identificador de pessoa.
- `scripts/reproduzir_resultados.py`: execução independente de manuscritos, pastas pessoais e repositórios prévios; verifica as saídas contra os CSV originais congelados.
- `resultados/`: coeficientes de todos os modelos, diagnósticos, seleção amostral, comparações CR1/HC3 e especificação S3.
- `protocolo/`: protocolo congelado, adendo pré-estimação, dicionário das variáveis e data card.
- `MANIFESTO_SHA256.json`: hashes individuais dos arquivos publicados.
- `FONTES_INEP.md`: páginas oficiais de acesso aos dados de origem e orientação de citação.
- `NOTAS_ETICA_E_PUBLICACAO.md`: limites de divulgação, de anonimização e normas da RAP.

## Replicar

Requer Python 3.11+ (recomendado), com NumPy, pandas e SciPy:

```bash
python -m pip install -r requirements.txt
python scripts/reproduzir_resultados.py --rapido
python scripts/reproduzir_resultados.py --saida reproducao_local
```

A opção `--rapido` verifica M0, M1, M2; a execução completa reestima S1, S2 e S3. A pasta `reproducao_local/` é gerada apenas quando `--saida` é informado e não entra no controle de versão. O script verifica o SHA-256 da base antes do cálculo e compara coeficientes, IC95% e valores *p* com as saídas congeladas. **A replicação pode exigir tempo e memória**, especialmente para o cálculo das matrizes de covariância e dos splines.

Verificação técnica do pacote realizada em 18/11/2026: M0, M1 e M2 (230 linhas), sensibilidades S1/S2 (242 linhas) e S3 (46 linhas) coincidiram com os resultados congelados (tolerância absoluta de 2 × 10⁻⁷ nas estimativas, IC e p-valores). Resultado M0 R²=0,450677525; M1=0,451773782; M2=0,451902623; S3=0,459297950.

## Inferência

O resultado principal usa CR1 por município, com correção de amostra finita G/(G−1) × (N−1)/(N−k) e inferência t(G−1). HC3 é complementar e **não incorpora dependência intramunicipal**. A pesquisa é observacional: não identifica efeitos causais, não mede diretamente FM ou capacidade estatal, e não avalia indivíduos.

## Origem e direitos

Dados derivados exclusivamente de **bases escolares e indicadores públicos do INEP** conforme `FONTES_INEP.md`. Não foram incluídos arquivos privados, versões do manuscrito, dados individuais, credenciais, e-mails ou materiais de avaliação editorial. O acesso público às fontes não dispensa verificar os termos vigentes de reutilização. Não se atribui a este pacote licença para materiais de terceiros nem licença autoral ao código sem aprovação dos coautores.

O código de replicação autônomo desta versão foi organizado com assistência de IA a partir do protocolo e dos scripts do estudo, com verificação numérica contra os resultados congelados. A responsabilidade científica e a decisão de publicação permanecem com os autores.

**Contato e citação do artigo:** preencher após decisão editorial e aprovação dos autores. Ainda não há DOI do artigo nem DOI de dados.
